# Written by T.J. Sego, Ph.D.

from matplotlib import pyplot as plt
from matplotlib import ticker
import os
from os.path import dirname

dir_env = os.path.join(dirname(dirname(__file__)), os.path.join('Model', 'GlazierModel', 'Model'))
dir_res = os.path.dirname(__file__)

# Plot labels
init_infect_frac_str = 'Initial infection fraction'
lamda_chemotaxis_str = 'Chemotaxis parameter'
local_sample_frac_str = 'Sampling fraction'
virus_diffusion_str = 'Virus diffusion coefficient ' + u'(\u03bc' + 'm' + r'$^2$/s)'
var_labels = {'init_infect': init_infect_frac_str,
              'lamda_chemotaxis': lamda_chemotaxis_str,
              'local_sample_frac': local_sample_frac_str,
              'virus_dc': virus_diffusion_str}

# rcParams definitions
rc_params_base = {'font.family': 'arial',
                  'savefig.dpi': 600}

rc_params_multiset = {'axes.labelsize': 6,
                      'axes.titlesize': 8,
                      'lines.markersize': 2}
rc_params_multiset.update(rc_params_base)

# Data set defs
export_data_desc_g = {'pop_data': ['Susceptible',
                                   'Infected',
                                   'Virusreleasing',
                                   'Dead',
                                   'Immunelocal',
                                   'Immunelymphnode'],
                      'death_data': ['Viral',
                                     'Contact'],
                      'med_diff_data': ['MedViral',
                                        'MedCyt',
                                        'MedCytL']}

# Results labels
y_label_str = {'med_diff_data': {'MedViral': 'Viral load',
                                 'MedCyt': 'Local cytokine',
                                 'MedCytL': 'Lymph cytokine'},
               'pop_data': {'Infected': 'Infected',
                            'Virusreleasing': 'Virus-releasing',
                            'Susceptible': 'Susceptible',
                            'Dead': 'Dead',
                            'Immunelocal': 'Local immune',
                            'Immunelymphnode': 'Lymph immune'},
               'death_data': {'Viral': 'Viral deaths',
                              'Contact': 'Contact deaths'}
               }

# Figure file names
fig_save_names_g = {'pop_data': {'Susceptible': 'metric_num_susceptible',
                                 'Infected': 'metric_num_infected',
                                 'Virusreleasing': 'metric_num_virusreleasing',
                                 'Dead': 'metric_num_dead',
                                 'Immunelocal': 'metric_num_immunelocal',
                                 'Immunelymphnode': 'metric_num_immunelymph'},
                    'med_diff_data': {'MedCytL': 'metric_lymph_cytokine'}}

# Plot manipulators
time_label = 'Simulation time (days)'
# Time step conversion (5 minutes per step)
time_scale = 5.0 / 60.0 / 24.0


def manip_plot_log(fig, ax):
    ax.set_yscale('log')


def manip_plot_axis_conv(fig, ax):
    # Convert time units to minutes and relabel
    ticks = ticker.FuncFormatter(lambda x, pos: '{0:g}'.format(x * time_scale))
    ax.xaxis.set_major_formatter(ticks)


def manip_plot_time_label(fig, ax):
    ax.set_xlabel(time_label)


def manip_set_ticks(xticks=None, yticks=None):
    def f(fig, ax):
        if xticks is not None:
            ax.set_xticks(xticks)
        if yticks is not None:
            ax.set_yticks(yticks)
    return f


def manip_plot_ode(fig, ax):
    ax.lines[-1].set_marker("None")
    ax.lines[-1].set_color('k')


def plot_lim_manip(bottom, top):
    def f(fig, ax):
        ax.axes.set_ylim(bottom=bottom, top=top)
    return f


def plot_hlim_manip(left, right):
    def f(fig, ax):
        ax.axes.set_xlim(left=left, right=right)
    return f


# Prototype addenda to batch post-processing


def generate_transient_subplot_trials(batch_data_summary, data_desc, var_name, fig, ax, manip=None):
    from BatchRun.BatchPostCoV2VTM import x_label_str_transient
    # Like generate_transient_plot_trials, but to a passed axis
    ax.grid()

    data_dict = batch_data_summary[data_desc]
    for trial_idx in data_dict.keys():
        if trial_idx in ['batchMean', 'batchStDev']:
            continue
        sim_mcs = list(data_dict[trial_idx].keys())
        y_data = [data_dict[trial_idx][this_mcs][var_name] for this_mcs in sim_mcs]
        ax.plot(sim_mcs, y_data, label='Trial {}'.format(trial_idx), marker='.')

    ax.set_xlabel(x_label_str_transient)
    ax.set_ylabel(y_label_str[data_desc][var_name])

    if manip is not None:
        manip(fig, ax)


def export_final_plots_trials(batch_data_summary, params: dict, filenames: dict, fig_height, fig_width,
                              manips: dict = None, rc_params: dict = None, big_fig_filename: str = None):
    if manips is not None:
        for p in manips.keys():
            assert any([p in pv for pv in params.values()]), f'Manipulator for {p} has not data'

    for k in batch_data_summary:
        assert k in params.keys(), f'No matching parameter list for data set {k}'

    for f in filenames.values():
        assert os.path.isdir(os.path.dirname(f)), f'Containing directory not found for {f}'

    if rc_params is not None:
        plt.rcParams.update(rc_params)

    n_plots = len(filenames.keys())

    big_fig, big_axes = plt.subplots(nrows=1, ncols=n_plots)
    big_fig.set_size_inches(w=n_plots * fig_width, h=fig_height)

    col_idx = 0
    saved_params = list()
    for k in batch_data_summary:
        for p in params[k]:
            if p not in filenames.keys():
                continue
            manip = None
            if manips is not None and p in manips.keys():
                manip = manips[p]
            generate_transient_subplot_trials(batch_data_summary, k, p, big_fig, big_axes[col_idx], manip)
            col_idx += 1
            saved_params.append(p)

    big_fig.tight_layout()
    if big_fig_filename is None:
        big_fig_path = os.path.join(os.path.dirname(__file__), "__bigfig.png")
        keep_big_fig = False
    else:
        big_fig_path = big_fig_filename
        keep_big_fig = True
    print(big_fig_path)
    big_fig.savefig(big_fig_path, bbox_inches='tight')
    plt.close()

    im = plt.imread(big_fig_path)
    h = int(im.shape[0])
    dw = int(im.shape[1] / n_plots)

    fig_counter = 0
    for iw in range(n_plots):
        imc = im[int(0):h, int(iw * dw):int((iw + 1) * dw)]
        fig = plt.figure(figsize=(fig_width, fig_height), dpi=600)
        fig.set_size_inches(w=fig_width, h=fig_height)
        ax = fig.add_subplot(111)
        ax.imshow(imc)
        plt.axis('off')
        fig_filename = filenames[saved_params[fig_counter]]
        print(fig_filename)
        fig.savefig(fig_filename)
        plt.close(fig)
        fig_counter += 1

    if not keep_big_fig:
        os.remove(big_fig_path)


class FigurePack:
    def __init__(self, subplot_specs=None):
        if subplot_specs is None:
            subplot_specs = [0, 0]
        self.fig, self.axes = plt.subplots(subplot_specs[0], subplot_specs[1])

        self.subplot_queue = None
        self.n_rows, self.n_cols = 0, 0
        if subplot_specs is not None:
            self.n_rows = subplot_specs[0]
            self.n_cols = subplot_specs[1]

    def figure(self):
        return self.fig

    def set_subplot_queue(self, _queue_specs):
        assert len(_queue_specs) == 2
        self.subplot_queue = _queue_specs
        if _queue_specs[0] > self.n_rows:
            self.n_rows = _queue_specs[0]
        if _queue_specs[1] > self.n_cols:
            self.n_cols = _queue_specs[1]

    def get_subplot(self, _queue_specs=None):
        if _queue_specs is None:
            _queue_specs = self.subplot_queue
        if len(self.axes.shape) == 1:
            return self.axes[max(_queue_specs[0], _queue_specs[1])]
        else:
            return self.axes[_queue_specs[0], _queue_specs[1]]

    def kill_figure(self):
        plt.close(self.fig)
        self.fig = None

    def show(self):
        assert self.fig is not None
        self.fig.show()


def format_grid_fig(figfig: FigurePack, param_vals_x, param_vals_y,
                    x_lims=None, y_lims=None, x_ticks=None, y_ticks=None,
                    x_label_str_var=None, y_label_str_var=None,
                    grid_plot_pads=None, manip=None):
    n_rows = figfig.n_rows
    n_cols = figfig.n_cols

    if manip is not None:
        [manip(figfig.fig, ax) for ax in figfig.axes.flat]

    # Share vertical
    axL = None
    for i in range(n_rows):
        for j in range(n_cols):
            ax = figfig.get_subplot((i, j))

            if j == 0:
                axL = ax
            else:
                axL.get_shared_y_axes().join(axL, ax)

    # Share horizontal axes
    axB = None
    for j in range(n_cols):
        for i in range(n_rows - 1, -1, -1):
            ax = figfig.get_subplot((i, j))

            if i == n_rows - 1:
                axB = ax
            else:
                axB.get_shared_x_axes().join(axB, ax)

    # Set labeling to only outer subplots
    for ax in figfig.axes.flat:
        ax.label_outer()

    # Set common x label
    x_lab_str = figfig.get_subplot((n_rows - 1, 0)).xaxis.get_label().get_text()

    # Set common y label
    y_lab_str = figfig.get_subplot((0, 0)).yaxis.get_label().get_text()

    # Replace x labels with one centered text
    for i in range(n_rows):
        for j in range(n_cols):
            figfig.get_subplot((i, j)).xaxis.get_label().set_text('')
    if grid_plot_pads is not None:
        figfig.fig.text(0.5, grid_plot_pads['bottom'], x_lab_str,
                        horizontalalignment='center',
                        verticalalignment='center')

    # Replace y labels with one centered text
    for i in range(n_rows):
        for j in range(n_cols):
            figfig.get_subplot((i, j)).yaxis.get_label().set_text('')
    if grid_plot_pads is not None:
        figfig.fig.text(grid_plot_pads['left'], 0.5, y_lab_str,
                        horizontalalignment='center',
                        verticalalignment='center',
                        rotation='vertical')

    # Add top title to each column to reflect varied parameter for each column
    for i in range(n_cols):
        ax = figfig.get_subplot((0, i))
        param_val = param_vals_x[i]
        if grid_plot_pads is not None:
            ax.text(0.5, 1 + grid_plot_pads['topMinor'], str(param_val),
                    horizontalalignment='center',
                    verticalalignment='bottom',
                    transform=ax.transAxes)
    if grid_plot_pads is not None and x_label_str_var is not None:
        figfig.fig.text(0.5, 1 - grid_plot_pads['top'], x_label_str_var,
                        horizontalalignment='center',
                        verticalalignment='center')

    # Add right title to each row to reflect varied parameter for each row
    if param_vals_y is not None:
        for i in range(n_rows):
            if param_vals_y[i] is None:
                continue
            ax = figfig.get_subplot((i, n_cols - 1))
            param_val = param_vals_y[i]
            if grid_plot_pads is not None:
                ax.text(1 + grid_plot_pads['rightMinor'], 0.5, str(param_val),
                        horizontalalignment='left',
                        verticalalignment='center',
                        transform=ax.transAxes,
                        rotation=270)
        if grid_plot_pads is not None and y_label_str_var is not None:
            figfig.fig.text(1 - grid_plot_pads['right'], 0.5, y_label_str_var,
                            horizontalalignment='center',
                            verticalalignment='center',
                            rotation=270)

    # Apply limits
    if x_lims is not None:
        [ax.set_xlim([x_lims[0], x_lims[1]]) for ax in figfig.axes.flat]
    if y_lims is not None:
        [ax.set_ylim([y_lims[0], y_lims[1]]) for ax in figfig.axes.flat]

    # Apply ticks
    if x_ticks is not None:
        [ax.set_xticks(x_ticks) for ax in figfig.axes.flat]
    if y_ticks is not None:
        [ax.set_yticks(y_ticks) for ax in figfig.axes.flat]

    # Set gridlines
    for ax in figfig.axes.flat:
        ax.grid(True, which='major', linewidth=1)
        ax.grid(True, which='minor', linewidth=0.1)
        ax.minorticks_on()
